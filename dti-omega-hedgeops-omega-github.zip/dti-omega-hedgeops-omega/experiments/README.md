# Experiment Registry

For each study, record: identifier, hypothesis, pre-registration, dataset provenance, protocol, treatment/control, baselines, primary metrics, uncertainty intervals, failure criteria, compute budget, ethical review, and reproducibility instructions.

**Current status:** No experiments or benchmark results included.
