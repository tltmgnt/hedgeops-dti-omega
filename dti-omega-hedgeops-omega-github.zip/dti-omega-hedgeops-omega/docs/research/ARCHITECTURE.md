# Proposed Architecture

```mermaid
flowchart TD
  A[Observe environment and temporal state] --> B[Represent joint latent state]
  B --> C[Estimate temporal option capacity]
  B --> D[Predict regimes and outcomes]
  C --> E[Generate feasible opportunities]
  D --> F[Counterfactual evaluation]
  E --> F
  F --> G[Epistemic agent arbitration]
  G --> H[Risk and autonomy constraints]
  H --> I[Execution feasibility gate]
  I --> J[Human-approved action]
  J --> K[Observe outcomes]
  K --> L[Calibration, causal evaluation, and learning]
  L --> A
```

The architecture is conceptual. No autonomous execution, live trading, or causal identification engine is implemented.
