# Research and Validation Plan

## Pre-registration checklist

Before data collection, specify primary outcomes, population, sample size and power, inclusion/exclusion criteria, randomization or identification strategy, baselines, statistical tests, missing-data policy, and stopping rules.

## Hypotheses

- **H1:** Temporal variables add out-of-sample explanatory/predictive value.
- **H2:** Continuity improves performance on high-switching-cost tasks.
- **H3:** Temporal autonomy improves opportunity selection under uncertainty.
- **H4:** Reality-feedback improves calibration during regime shifts.
- **H5:** Epistemically differentiated ensembles outperform matched-complexity homogeneous ensembles under distribution shift.
- **H6:** Joint modeling improves feasible opportunity allocation beyond either component alone.
- **H7:** Positive slack has option value under sufficiently high uncertainty.

## Proposed experiments

1. **Capacity prediction:** temporal features versus productivity-only baselines; evaluate held-out participants and time periods.
2. **Opportunity allocation:** scheduling baseline, DTI-only, HedgeOps-only, integrated architecture; matched budgets and compute.
3. **Regime shock:** simulated and, where feasible, real-world shifts; assess recovery and downside exposure.
4. **Causal evaluation:** randomized interventions or defensible quasi-experimental identification; avoid inferring `do(A)` from correlation alone.
5. **Human–AI collaboration:** human-only, AI-only, homogeneous ensemble, differentiated ensemble, integrated system; measure overreliance and burden.

## Required comparisons

Report ablations, confidence intervals, subgroup results, calibration, risk, compute cost, and negative findings. Avoid data leakage and report all pre-specified primary outcomes.

## Falsification

The integrated framework is weakened if operational measures are unreliable, incremental predictive value vanishes, intervention effects are null, matched baselines perform equally well, or autonomy/recovery costs outweigh benefits.
