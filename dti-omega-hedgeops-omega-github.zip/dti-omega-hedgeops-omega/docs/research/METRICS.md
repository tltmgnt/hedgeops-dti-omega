# Candidate Metrics (Not Yet Validated)

| Construct | Proposed operationalization | Main caveat |
|---|---|---|
| TOC | Weighted count/value of feasible, executable options in a defined horizon | Requires validated option set and weights |
| TEV | Expected enabled economic value / discretionary time consumed | Avoid double-counting future value |
| TFI | Fragment counts, duration distribution, gaps, interruptions | Task-dependent effects |
| TODV | Expected value conditional on opportunity, capacity, risk, uncertainty | Conditional expectation is not a causal effect |
| OCME | Realized value of successfully matched opportunities / actionable capacity | Units and denominator must be defined |
| RCC | Composite of capacity, calibration, adaptation, autonomy and risk | Weights and construct validity unknown |
| TSR | Joint temporal and systemic fragility measures | Graph product requires precise definition |
| Calibration | Brier score, log loss, reliability plots | Must define target events and horizons |
| Human impact | Autonomy, recovery, well-being, workload | Use validated instruments where possible |

Specify normalization, sampling windows, missingness, and uncertainty intervals before comparisons. The spectral radius/eigenvalue of a covariance matrix is at most a candidate concentration proxy, not a complete systemic-risk measure.
