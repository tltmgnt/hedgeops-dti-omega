# Contributing

Contributions are welcome in measurement design, literature review, causal identification, simulation, baselines, replication, and critique. Open an issue describing the claim, proposed test, assumptions, and evidence. Distinguish hypotheses from findings; document datasets and permissions; never commit private schedules, personal data, or credentials. Avoid overstating model capabilities or causal claims.
