# DTI Ω × HedgeOps Ω

**A Unified Architecture for Temporal Capacity, Reality-Convergent Intelligence, and Decision Control Under Uncertainty**

> Every discretionary second is an option. Every decision is a hypothesis about reality.

**Status:** Proposed research architecture. The hypotheses, constructs, and integrated performance claims have **not** been empirically validated.

## Overview

DTI Ω (Discretionary Time Intelligence) models the capacity to take action as an explicit state variable. HedgeOps Ω proposes a decision-control architecture for partially observable, nonstationary environments. Their integration investigates whether jointly modeling external conditions and internal execution capacity improves decisions relative to simpler alternatives.

The proposed dual state is:

$$Z_t=(M_t,\Theta_t)$$

- $M_t$: latent external economic/environmental state.
- $\Theta_t$: latent temporal-capacity state.

The proposed control loop is:

**Capacity → Intelligence → Opportunity → Decision → Action → Reality → Learning**

## Research questions

1. Do temporal-capacity variables add predictive value beyond conventional scheduling and productivity measures?
2. Does structured epistemic diversity improve robustness under distribution shift?
3. Does joint state modeling improve feasible opportunity allocation compared with single-component systems?
4. Can temporal slack provide measurable option value under uncertainty?
5. Can these improvements occur without compromising autonomy, recovery, or well-being?

## Repository map

- [`docs/WHITEPAPER.md`](docs/WHITEPAPER.md): complete proposed framework and 45 sections.
- [`docs/research/RESEARCH_PLAN.md`](docs/research/RESEARCH_PLAN.md): validation plan and preregistration considerations.
- [`docs/research/METRICS.md`](docs/research/METRICS.md): candidate operational measures and cautions.
- [`docs/research/ARCHITECTURE.md`](docs/research/ARCHITECTURE.md): component boundaries and data flow.
- [`experiments/README.md`](experiments/README.md): experiment registry template.
- [`src/dti_hedgeops/`](src/dti_hedgeops/): reserved for reference implementation; no production model is claimed.

## Scientific integrity

All equations and constructs are **proposals**, not established empirical laws. In particular, observational conditional expectations must not be treated as causal effects without an identification strategy. Simulation evidence alone is not proof of real-world effectiveness. No benchmark results are claimed in this repository.

## Contribution

See [CONTRIBUTING.md](CONTRIBUTING.md). Criticism, replications, null results, and simpler baselines are welcome.

## License

**No license has been selected yet.** All rights remain reserved by default until the rights holder adds a license. Choose a code license and, if desired, a separate document license before inviting reuse.
