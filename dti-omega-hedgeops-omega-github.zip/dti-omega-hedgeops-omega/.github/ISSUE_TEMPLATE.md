## Research issue

**Claim or hypothesis:**

**Evidence / relevant literature:**

**Proposed falsifiable test:**

**Baselines and confounders:**

**Data and privacy considerations:**
